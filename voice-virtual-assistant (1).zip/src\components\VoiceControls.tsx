'use strict';
'use client';

import React, { useState } from 'react';
import {
  Volume2,
  VolumeX,
  Pause,
  Play,
  Square,
  Trash2,
  Settings,
  ChevronDown,
} from 'lucide-react';

interface VoiceControlsProps {
  voiceEnabled: boolean;
  onToggleVoice: () => void;
  isSpeaking: boolean;
  isPaused: boolean;
  onPauseSpeech: () => void;
  onResumeSpeech: () => void;
  onStopSpeech: () => void;
  voices: SpeechSynthesisVoice[];
  selectedVoiceURI: string | null;
  onSelectVoice: (voiceURI: string) => void;
  speechRate: number;
  onChangeRate: (rate: number) => void;
  onClearConversation: () => void;
  messageCount: number;
}

export const VoiceControls: React.FC<VoiceControlsProps> = ({
  voiceEnabled,
  onToggleVoice,
  isSpeaking,
  isPaused,
  onPauseSpeech,
  onResumeSpeech,
  onStopSpeech,
  voices,
  selectedVoiceURI,
  onSelectVoice,
  speechRate,
  onChangeRate,
  onClearConversation,
  messageCount,
}) => {
  const [showVoiceSettings, setShowVoiceSettings] = useState(false);

  return (
    <div className="w-full flex flex-col gap-2 pt-2 pb-1 border-t border-slate-800/80">
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs">
        {/* Left Side: Voice Response On/Off Toggle & Playback Controls */}
        <div className="flex items-center gap-2">
          {/* Toggle Voice Output On/Off */}
          <button
            type="button"
            onClick={onToggleVoice}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border font-medium transition-all focus:outline-none focus:ring-2 focus:ring-cyan-400 ${
              voiceEnabled
                ? 'bg-cyan-950/40 border-cyan-700/60 text-cyan-300 hover:bg-cyan-900/50'
                : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:bg-slate-800 hover:text-slate-300'
            }`}
            aria-pressed={voiceEnabled}
            aria-label={voiceEnabled ? 'Disable voice responses' : 'Enable voice responses'}
          >
            {voiceEnabled ? (
              <>
                <Volume2 className="w-4 h-4 text-cyan-400" />
                <span>Voice: On</span>
              </>
            ) : (
              <>
                <VolumeX className="w-4 h-4 text-slate-400" />
                <span>Voice: Off</span>
              </>
            )}
          </button>

          {/* Active Speech Controls (Pause, Resume, Stop) when Speaking */}
          {isSpeaking && (
            <div className="flex items-center gap-1 bg-slate-900/80 border border-emerald-500/40 px-2 py-1 rounded-lg">
              {isPaused ? (
                <button
                  type="button"
                  onClick={onResumeSpeech}
                  className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 px-1.5 py-0.5 rounded transition-colors"
                  aria-label="Resume speech playback"
                  title="Resume speech"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span className="font-medium">Resume</span>
                </button>
              ) : (
                <button
                  type="button"
                  onClick={onPauseSpeech}
                  className="flex items-center gap-1 text-amber-400 hover:text-amber-300 px-1.5 py-0.5 rounded transition-colors"
                  aria-label="Pause speech playback"
                  title="Pause speech"
                >
                  <Pause className="w-3.5 h-3.5 fill-current" />
                  <span className="font-medium">Pause</span>
                </button>
              )}

              <button
                type="button"
                onClick={onStopSpeech}
                className="flex items-center gap-1 text-red-400 hover:text-red-300 px-1.5 py-0.5 rounded transition-colors ml-1 border-l border-slate-700 pl-2"
                aria-label="Stop speech playback"
                title="Stop speech"
              >
                <Square className="w-3 h-3 fill-current" />
                <span className="font-medium">Stop</span>
              </button>
            </div>
          )}

          {/* Voice Config Dropdown Trigger */}
          {voices.length > 0 && (
            <button
              type="button"
              onClick={() => setShowVoiceSettings(!showVoiceSettings)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-800 bg-slate-900/60 text-slate-400 hover:text-slate-200 hover:border-slate-700 transition-colors focus:ring-2 focus:ring-cyan-400"
              aria-expanded={showVoiceSettings}
              aria-label="Adjust voice sound settings"
            >
              <Settings className="w-3.5 h-3.5" />
              <span>Voice Settings</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform duration-200 ${
                  showVoiceSettings ? 'rotate-180' : ''
                }`}
              />
            </button>
          )}
        </div>

        {/* Right Side: Clear Conversation Button */}
        {messageCount > 0 && (
          <button
            type="button"
            onClick={onClearConversation}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-800 bg-slate-900/40 text-slate-400 hover:text-rose-400 hover:border-rose-900/50 hover:bg-rose-950/20 transition-colors focus:ring-2 focus:ring-rose-400"
            aria-label="Clear all conversation messages"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Chat</span>
          </button>
        )}
      </div>

      {/* Expandable Voice Preference Tray */}
      {showVoiceSettings && voices.length > 0 && (
        <div className="mt-2 p-3 rounded-xl bg-slate-900/90 border border-slate-700/60 backdrop-blur-md grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs animate-fade-in">
          {/* Voice Picker */}
          <div>
            <label htmlFor="voice-select" className="block text-slate-300 font-medium mb-1">
              Browser Voice:
            </label>
            <select
              id="voice-select"
              value={selectedVoiceURI || ''}
              onChange={(e) => onSelectVoice(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2.5 py-1.5 text-slate-200 focus:outline-none focus:ring-2 focus:ring-cyan-400"
            >
              {voices.map((voice) => (
                <option key={voice.voiceURI} value={voice.voiceURI}>
                  {voice.name} ({voice.lang})
                </option>
              ))}
            </select>
          </div>

          {/* Voice Speed Slider */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label htmlFor="speed-slider" className="text-slate-300 font-medium">
                Speech Speed:
              </label>
              <span className="text-cyan-400 font-mono">{speechRate}x</span>
            </div>
            <input
              id="speed-slider"
              type="range"
              min="0.75"
              max="1.5"
              step="0.05"
              value={speechRate}
              onChange={(e) => onChangeRate(parseFloat(e.target.value))}
              className="w-full h-1.5 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
          </div>
        </div>
      )}
    </div>
  );
};
