export type Role = 'user' | 'assistant' | 'system';

export interface ChatMessage {
  id: string;
  role: Role;
  content: string;
  timestamp: number;
  provider?: string;
  model?: string;
  isSpoken?: boolean;
}

export type VoiceState = 'idle' | 'listening' | 'processing' | 'speaking' | 'error';

export type LLMProvider = 'groq' | 'openai' | 'gemini' | 'demo';

export interface PersonalityPreset {
  id: string;
  name: string;
  description: string;
  icon: string;
  systemPrompt: string;
}

export interface AudioSettings {
  voiceURI: string;
  rate: number;
  pitch: number;
  volume: number;
  autoSpeak: boolean;
  pushToTalk: boolean;
}

export interface ProviderConfigStatus {
  groqConfigured: boolean;
  openaiConfigured: boolean;
  geminiConfigured: boolean;
  activeDefault: LLMProvider;
}
