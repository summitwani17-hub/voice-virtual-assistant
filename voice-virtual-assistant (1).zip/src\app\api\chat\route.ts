import { NextRequest, NextResponse } from 'next/server';
import { processUserMessage, ChatMessageItem } from '@/lib/ai';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json().catch(() => null);

    if (!body || typeof body !== 'object') {
      return NextResponse.json(
        { error: 'Invalid request body. Expected JSON object with a "messages" array.' },
        { status: 400 }
      );
    }

    const { messages, provider, model, systemPrompt } = body as {
      messages?: ChatMessageItem[];
      provider?: string;
      model?: string;
      systemPrompt?: string;
    };

    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json(
        { error: 'The "messages" array is required and must not be empty.' },
        { status: 400 }
      );
    }

    const lastMessage = messages[messages.length - 1];
    if (!lastMessage || typeof lastMessage.content !== 'string' || !lastMessage.content.trim()) {
      return NextResponse.json(
        { error: 'The latest message must contain non-empty text content.' },
        { status: 400 }
      );
    }

    // Call the server-side AI processor
    const reply = await processUserMessage(messages, {
      provider,
      model,
      systemPrompt,
    });

    // Provide the required response format: { "message": "..." }
    // along with "content" for broad compatibility
    return NextResponse.json({
      message: reply,
      content: reply,
      timestamp: new Date().toISOString(),
    });
  } catch (error: unknown) {
    console.error('Error in /api/chat handler:', error);

    const errorMessage = error instanceof Error ? error.message : 'An unexpected server error occurred.';
    
    // Check if error corresponds to rate limiting or timeouts
    let status = 500;
    if (errorMessage.toLowerCase().includes('timed out')) {
      status = 504;
    } else if (errorMessage.toLowerCase().includes('rate limit') || errorMessage.toLowerCase().includes('429')) {
      status = 429;
    }

    return NextResponse.json(
      {
        error: errorMessage,
        message: 'I encountered an issue processing your voice request. Please try again in a moment.',
      },
      { status }
    );
  }
}
