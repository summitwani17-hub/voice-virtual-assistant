# VoxAI - Your Voice-Based Virtual Assistant

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new)

A modern, production-grade, Vercel-ready **Voice-Based Virtual Assistant** web application built with **Next.js 15+ (App Router)**, **TypeScript**, and **Tailwind CSS**.

VoxAI allows users to communicate naturally through their microphone or text, converting voice to text in real time, processing conversational context via secure server-side AI providers, and responding with natural spoken voice synthesis alongside dynamic audio visualizations.

---

## 🌟 Key Features

### 1. Voice Input (Speech-to-Text)
- **Large Central Microphone Button**: Prominently displayed with fluid glowing animations for idle, listening, thinking, and speaking states.
- **Web Speech API Integration**: Leverages native browser `SpeechRecognition` / `webkitSpeechRecognition` for zero-latency, private client-side speech recognition.
- **Real-Time Transcription**: Live interim transcription preview as you speak.
- **Comprehensive Controls**: **Start**, **Stop**, and **Cancel** controls with keyboard navigation (Space/Enter to speak, Escape to cancel).
- **Graceful Fallbacks**: Clear detection and actionable notifications for unsupported browsers or denied microphone permissions.

### 2. Intelligent AI Conversation
- **Multi-Provider Server-Side Processing**: Connects seamlessly with **Groq** (ultra-low latency LLaMA 3.3), **OpenAI** (GPT-4o-mini), or **Google Gemini** (Gemini 1.5 Flash).
- **Zero-Config Smart Fallback Engine**: If no API keys are provided in `.env.local`, VoxAI immediately works out of the box using a built-in intelligent conversational assistant.
- **Session History**: Maintains full conversational context across turns with clean speech-friendly phrasing.
- **Assistant Capabilities**:
  - Explains concepts and academic study questions.
  - Summarizes text and extracts key points.
  - Brainstorms creative project and business ideas.
  - Solves basic math and arithmetic calculations.
  - Transparent boundary handling (clearly states when a request requires external hardware or private account actions).

### 3. Voice Output (Text-to-Speech)
- **Natural Voice Synthesis**: Uses browser `window.speechSynthesis` with multi-accent voice detection.
- **Playback Controls**: Full **Pause**, **Resume**, and **Stop** controls when reading responses aloud.
- **Voice Response Toggle**: Easily enable or disable automatic spoken responses.
- **Per-Message Speech**: Replay any assistant message at any time with active audio equalizer badges.
- **Voice Customization**: Choose between installed browser voices and adjust speech playback rates (0.75x - 1.5x).

### 4. Modern Futuristic User Interface
- **Dark & Light Mode**: Seamless theme switching with high contrast and smooth color transitions.
- **Glassmorphic Design**: Frosted glass panels, ambient blur glows, and responsive rounded cards.
- **Accessible & Screen-Reader Ready**: Complete ARIA attributes, semantic HTML5, visible focus rings, and live regions.
- **Mobile-First Layout**: Fully responsive experience optimized for smartphones, tablets, and desktop displays.

---

## 🏗️ Architecture & Project Structure

```
voice-virtual-assistant/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   └── chat/
│   │   │       └── route.ts        # Secure server-side AI endpoint (POST /api/chat)
│   │   ├── globals.css             # Tailwind v4 styles & custom audio animations
│   │   ├── layout.tsx              # SEO metadata, font config, viewport
│   │   └── page.tsx                # Main entry point mounting VoiceAssistant
│   ├── components/
│   │   ├── VoiceAssistant.tsx      # Main application state and layout container
│   │   ├── MicrophoneButton.tsx    # Central animated mic button with audio rings
│   │   ├── ChatMessage.tsx         # Message bubbles, copy button, and speech triggers
│   │   └── VoiceControls.tsx       # Voice toggle, pause/resume/stop, voice selector
│   ├── hooks/
│   │   ├── useSpeechRecognition.ts # Web Speech STT management & permission hooks
│   │   └── useSpeechSynthesis.ts   # SpeechSynthesis TTS playback & voice management
│   ├── lib/
│   │   └── ai.ts                   # Server-side AI engine (Groq, OpenAI, Gemini, Smart Fallback)
│   └── types/
│       └── assistant.ts            # Shared TypeScript interfaces
├── public/                         # Static assets
├── .env.example                    # Environment variable template
├── package.json                    # Dependencies and scripts
├── tsconfig.json                   # TypeScript compiler configuration
└── README.md                       # Documentation
```

### API Security Contract
The client makes requests to `POST /api/chat`:
```json
{
  "messages": [
    {
      "role": "user",
      "content": "What is photosynthesis?"
    }
  ]
}
```
And receives:
```json
{
  "message": "Photosynthesis is the process by which green plants and some organisms turn sunlight, water, and carbon dioxide into oxygen and glucose for energy."
}
```
**API keys (`GROQ_API_KEY`, `OPENAI_API_KEY`, `GEMINI_API_KEY`) remain strictly server-side** and are never bundled into client JavaScript.

---

## 🚀 Quick Start Guide

### Prerequisites
- Node.js 18.18.0 or higher
- npm (or yarn / pnpm)

### 1. Installation
Clone the repository and install dependencies:
```bash
git clone https://github.com/your-username/voice-virtual-assistant.git
cd voice-virtual-assistant
npm install
```

### 2. Environment Setup (Optional)
The assistant includes an offline smart assistant engine, so you can test it immediately without any keys! To connect real cloud AI models:

```bash
cp .env.example .env.local
```

Edit `.env.local` with your preferred provider:
```ini
# Recommended: Groq provides near-instant responses for voice
GROQ_API_KEY=gsk_your_groq_api_key_here

# Or OpenAI:
# OPENAI_API_KEY=sk-proj-your_openai_key_here

# Or Google Gemini:
# GEMINI_API_KEY=AIzaSy_your_gemini_key_here
```

### 3. Run Locally
Start the Next.js development server:
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

---

## 📦 Production Build & Testing

Run type checking, linting, and build verification:
```bash
# Verify TypeScript and create production bundle
npm run build

# Start production server
npm start
```

---

## 🌐 Deploying to Vercel

VoxAI is built natively for Vercel deployment with zero additional configuration required.

### Method 1: Deploy with Vercel CLI
```bash
npm install -g vercel
vercel
```

Follow the prompts, link your project, and set environment variables:
```bash
vercel env add GROQ_API_KEY
vercel --prod
```

### Method 2: Deploy via Vercel Dashboard (Git)
1. Push your repository to GitHub, GitLab, or Bitbucket.
2. Go to [https://vercel.com/new](https://vercel.com/new).
3. Import your `voice-virtual-assistant` repository.
4. In **Environment Variables**, add:
   - `GROQ_API_KEY` (or `OPENAI_API_KEY` / `GEMINI_API_KEY`)
5. Click **Deploy**. Vercel will build and assign an SSL-enabled production domain in under a minute!

---

## 🧭 Browser Compatibility

| Browser | Speech-to-Text (STT) | Text-to-Speech (TTS) | Recommended |
| :--- | :---: | :---: | :---: |
| **Google Chrome** (Desktop & Android) | ✅ Full Support | ✅ Full Support | ⭐ Best Experience |
| **Microsoft Edge** | ✅ Full Support | ✅ Full Support | ⭐ Excellent |
| **Apple Safari** (macOS & iOS 14.5+) | ✅ Supported | ✅ Full Support | ⭐ Great |
| **Mozilla Firefox** | ⚠️ Text Fallback | ✅ Full Support | Type-to-Chat Supported |

> **Note on Mobile Browsers**: iOS Safari and Chrome Android require a user gesture (tapping the microphone button) before capturing audio or playing synthesized speech, which VoxAI handles by default.

---

## 🛠️ Troubleshooting

| Issue | Cause | Solution |
| :--- | :--- | :--- |
| **"Microphone access was denied"** | Browser microphone permissions blocked. | Click the lock/tune icon in the browser address bar and switch **Microphone** to **Allow**, then refresh. |
| **"Speech recognition not available"** | Browser lacks Web Speech API (e.g., Firefox). | Use Chrome, Edge, or Safari, or use the interactive text input box directly. |
| **No audio output heard** | System audio muted or voice responses turned off. | 1. Ensure the **Voice: On** toggle is enabled.<br>2. Check your device volume output.<br>3. Open **Voice Settings** and select an alternative voice from the dropdown. |
| **AI response error** | Missing or invalid API key or rate limit. | Check your server logs or `.env.local` file to confirm your `GROQ_API_KEY` or `OPENAI_API_KEY` is valid. |

---

## 🔒 Privacy & Safety
- **No permanent audio recording**: Speech is converted into text directly in the browser using the Web Speech API and discarded immediately.
- **Opt-in audio input**: The microphone is only active when the user explicitly clicks the center button.
- **Secure transmission**: Server communication uses HTTPS with strict server-side environment variable encapsulation.

---

## 📄 License
MIT License. Created for the Voice-Based Virtual Assistant project.
