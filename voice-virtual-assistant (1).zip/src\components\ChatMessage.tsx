'use strict';
'use client';

import React, { useState } from 'react';
import { User, Bot, Volume2, Square, Copy, Check } from 'lucide-react';

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

interface ChatMessageProps {
  message: Message;
  isCurrentlySpeaking: boolean;
  onSpeak: (text: string, messageId: string) => void;
  onStopSpeech: () => void;
}

export const ChatMessage: React.FC<ChatMessageProps> = ({
  message,
  isCurrentlySpeaking,
  onSpeak,
  onStopSpeech,
}) => {
  const [copied, setCopied] = useState(false);
  const isUser = message.role === 'user';

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(message.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback if clipboard API is not available
    }
  };

  const handleToggleSpeak = () => {
    if (isCurrentlySpeaking) {
      onStopSpeech();
    } else {
      onSpeak(message.content, message.id);
    }
  };

  return (
    <div
      className={`flex items-start gap-3 w-full my-3 transition-opacity duration-300 ${
        isUser ? 'flex-row-reverse' : 'flex-row'
      }`}
    >
      {/* Avatar Icon */}
      <div
        className={`w-9 h-9 rounded-full flex items-center justify-center shrink-0 shadow-md ${
          isUser
            ? 'bg-gradient-to-tr from-cyan-600 to-blue-600 text-white'
            : 'bg-gradient-to-tr from-purple-600 to-indigo-700 text-white'
        }`}
        aria-hidden="true"
      >
        {isUser ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
      </div>

      {/* Message Content Bubble */}
      <div
        className={`flex flex-col max-w-[85%] sm:max-w-[75%] ${
          isUser ? 'items-end' : 'items-start'
        }`}
      >
        {/* Author Label & Timestamp */}
        <div className="flex items-center gap-2 mb-1 px-1 text-xs text-slate-400">
          <span className="font-semibold text-slate-300">
            {isUser ? 'You' : 'VoxAI Assistant'}
          </span>
          <span>•</span>
          <time dateTime={message.timestamp}>{message.timestamp}</time>
        </div>

        {/* Message Bubble Box */}
        <div
          className={`relative group px-4 py-3 rounded-2xl text-sm leading-relaxed shadow-lg break-words ${
            isUser
              ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white rounded-tr-none'
              : 'bg-slate-900/80 border border-slate-700/60 text-slate-100 rounded-tl-none backdrop-blur-md'
          } ${
            isCurrentlySpeaking ? 'ring-2 ring-emerald-400/70 border-emerald-500/50 shadow-emerald-500/20' : ''
          }`}
        >
          {/* Active speech equalizer animation badge for assistant */}
          {isCurrentlySpeaking && !isUser && (
            <div className="flex items-center gap-1 mb-2 text-xs font-medium text-emerald-400">
              <span className="flex items-center gap-0.5">
                <span className="w-1 h-3 bg-emerald-400 animate-pulse rounded-full" />
                <span className="w-1 h-4 bg-emerald-400 animate-pulse delay-75 rounded-full" />
                <span className="w-1 h-2 bg-emerald-400 animate-pulse delay-150 rounded-full" />
              </span>
              <span>Speaking response aloud...</span>
            </div>
          )}

          <p className="whitespace-pre-wrap">{message.content}</p>

          {/* Action Toolbar on Hover / Focus */}
          <div
            className={`flex items-center gap-1.5 mt-2 pt-2 border-t text-xs ${
              isUser
                ? 'border-white/20 justify-end text-cyan-100'
                : 'border-slate-800 justify-start text-slate-400'
            }`}
          >
            {/* Speak / Stop Button (for Assistant) */}
            {!isUser && (
              <button
                type="button"
                onClick={handleToggleSpeak}
                className={`flex items-center gap-1 px-2 py-0.5 rounded transition-colors ${
                  isCurrentlySpeaking
                    ? 'bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30'
                    : 'hover:bg-slate-800 hover:text-slate-200'
                }`}
                title={isCurrentlySpeaking ? 'Stop speaking' : 'Read message aloud'}
                aria-label={isCurrentlySpeaking ? 'Stop speaking' : 'Read message aloud'}
              >
                {isCurrentlySpeaking ? (
                  <>
                    <Square className="w-3 h-3 fill-current text-emerald-400" />
                    <span>Stop</span>
                  </>
                ) : (
                  <>
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>Read</span>
                  </>
                )}
              </button>
            )}

            {/* Copy Button */}
            <button
              type="button"
              onClick={handleCopy}
              className={`flex items-center gap-1 px-2 py-0.5 rounded transition-colors ${
                isUser
                  ? 'hover:bg-white/20'
                  : 'hover:bg-slate-800 hover:text-slate-200'
              }`}
              title="Copy message"
              aria-label="Copy message text"
            >
              {copied ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400">Copied</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
