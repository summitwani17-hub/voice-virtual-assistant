'use strict';
'use client';

import React from 'react';
import { Mic, MicOff, Square, X, Loader2, Volume2, AlertCircle } from 'lucide-react';

export type AssistantVoiceState = 'idle' | 'listening' | 'thinking' | 'speaking';

interface MicrophoneButtonProps {
  voiceState: AssistantVoiceState;
  isSupported: boolean;
  permissionDenied: boolean;
  onStart: () => void;
  onStop: () => void;
  onCancel: () => void;
  disabled?: boolean;
}

export const MicrophoneButton: React.FC<MicrophoneButtonProps> = ({
  voiceState,
  isSupported,
  permissionDenied,
  onStart,
  onStop,
  onCancel,
  disabled = false,
}) => {
  const isListening = voiceState === 'listening';
  const isThinking = voiceState === 'thinking';
  const isSpeaking = voiceState === 'speaking';

  // Determine main action click
  const handleMainClick = () => {
    if (disabled || !isSupported || permissionDenied) return;

    if (isListening) {
      onStop();
    } else {
      onStart();
    }
  };

  // Keyboard shortcut handler
  const handleKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if (e.key === ' ' || e.key === 'Enter') {
      e.preventDefault();
      handleMainClick();
    } else if (e.key === 'Escape' && isListening) {
      e.preventDefault();
      onCancel();
    }
  };

  return (
    <div className="flex flex-col items-center justify-center relative py-6">
      {/* Background Animated Glow Halo Rings */}
      <div className="relative flex items-center justify-center">
        {/* Pulsing ring during listening */}
        {isListening && (
          <>
            <span
              className="absolute -inset-4 rounded-full bg-red-500/25 blur-xl animate-ping opacity-75"
              aria-hidden="true"
            />
            <span
              className="absolute -inset-8 rounded-full border-2 border-red-500/40 animate-pulse"
              aria-hidden="true"
            />
            <span
              className="absolute -inset-12 rounded-full border border-red-500/20 animate-ping opacity-50"
              aria-hidden="true"
            />
          </>
        )}

        {/* Cyan/Violet ring during speaking */}
        {isSpeaking && (
          <>
            <span
              className="absolute -inset-4 rounded-full bg-emerald-500/20 blur-xl animate-pulse"
              aria-hidden="true"
            />
            <span
              className="absolute -inset-8 rounded-full border-2 border-emerald-400/40 animate-pulse"
              aria-hidden="true"
            />
          </>
        )}

        {/* Spinning ring during thinking */}
        {isThinking && (
          <span
            className="absolute -inset-3 rounded-full border-2 border-dashed border-cyan-400/60 animate-spin"
            aria-hidden="true"
          />
        )}

        {/* Ambient glow in idle */}
        {voiceState === 'idle' && !disabled && isSupported && !permissionDenied && (
          <span
            className="absolute -inset-2 rounded-full bg-cyan-500/15 blur-lg transition-all duration-500 group-hover:bg-cyan-500/30"
            aria-hidden="true"
          />
        )}

        {/* Main Center Microphone Button */}
        <button
          type="button"
          onClick={handleMainClick}
          onKeyDown={handleKeyDown}
          disabled={disabled || !isSupported || permissionDenied}
          aria-label={
            !isSupported
              ? 'Speech recognition not supported in this browser'
              : permissionDenied
              ? 'Microphone permission denied'
              : isListening
              ? 'Stop recording voice'
              : isThinking
              ? 'Assistant is thinking'
              : isSpeaking
              ? 'Assistant is speaking'
              : 'Tap to start speaking'
          }
          className={`
            relative z-10 w-28 h-28 sm:w-32 sm:h-32 rounded-full flex flex-col items-center justify-center
            transition-all duration-300 transform active:scale-95 shadow-2xl focus:outline-none focus:ring-4
            ${
              !isSupported || permissionDenied
                ? 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                : isListening
                ? 'bg-gradient-to-tr from-red-600 to-rose-500 text-white shadow-red-500/50 scale-105 ring-4 ring-red-400/50'
                : isThinking
                ? 'bg-gradient-to-tr from-amber-600 to-cyan-600 text-white shadow-cyan-500/40 scale-100 ring-4 ring-cyan-400/30'
                : isSpeaking
                ? 'bg-gradient-to-tr from-emerald-600 to-teal-500 text-white shadow-emerald-500/40 ring-4 ring-emerald-400/50'
                : 'bg-gradient-to-tr from-cyan-600 via-indigo-600 to-violet-600 hover:from-cyan-500 hover:to-violet-500 text-white shadow-cyan-500/30 hover:scale-105 hover:shadow-cyan-500/50'
            }
          `}
        >
          {/* Icon state */}
          {!isSupported || permissionDenied ? (
            <MicOff className="w-10 h-10 sm:w-12 sm:h-12" />
          ) : isListening ? (
            <div className="flex flex-col items-center">
              <Square className="w-9 h-9 sm:w-10 sm:h-10 fill-current animate-pulse mb-1" />
              <span className="text-[10px] font-semibold tracking-wider uppercase">Tap to Stop</span>
            </div>
          ) : isThinking ? (
            <div className="flex flex-col items-center">
              <Loader2 className="w-10 h-10 sm:w-12 sm:h-12 animate-spin mb-1" />
              <span className="text-[10px] font-semibold tracking-wider uppercase">Thinking</span>
            </div>
          ) : isSpeaking ? (
            <div className="flex flex-col items-center">
              <Volume2 className="w-10 h-10 sm:w-12 sm:h-12 animate-bounce mb-1" />
              <span className="text-[10px] font-semibold tracking-wider uppercase">Speaking</span>
            </div>
          ) : (
            <div className="flex flex-col items-center">
              <Mic className="w-11 h-11 sm:w-12 sm:h-12 transition-transform duration-200 group-hover:scale-110" />
            </div>
          )}
        </button>
      </div>

      {/* Auxiliary Controls (Start, Stop, Cancel) during active recording */}
      {isListening && (
        <div className="flex items-center gap-3 mt-4 animate-fade-in">
          <button
            type="button"
            onClick={onStop}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-medium bg-red-600/20 text-red-300 border border-red-500/40 hover:bg-red-600/30 transition-colors focus:ring-2 focus:ring-red-400"
            aria-label="Finish and send recording"
          >
            <Square className="w-3.5 h-3.5 fill-current" />
            Done Speaking
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-medium bg-slate-800/80 text-slate-300 border border-slate-700 hover:bg-slate-700 transition-colors focus:ring-2 focus:ring-slate-400"
            aria-label="Cancel recording without sending"
          >
            <X className="w-3.5 h-3.5" />
            Cancel
          </button>
        </div>
      )}

      {/* Dynamic Sound Wave Visualizer Bar Indicator */}
      {(isListening || isSpeaking) && (
        <div className="flex items-center gap-1 h-6 mt-4" aria-hidden="true">
          {[40, 75, 100, 60, 90, 45, 80, 50, 95, 65, 35].map((height, idx) => (
            <span
              key={idx}
              className={`w-1 rounded-full transition-all duration-150 ${
                isListening ? 'bg-red-400' : 'bg-emerald-400'
              }`}
              style={{
                height: `${height}%`,
                animation: 'soundwave-pulse 0.9s ease-in-out infinite',
                animationDelay: `${idx * 0.08}s`,
              }}
            />
          ))}
        </div>
      )}

      {/* Primary Status Text as specified in requirements */}
      <div className="mt-4 text-center" aria-live="polite">
        <p
          className={`text-base sm:text-lg font-medium tracking-wide ${
            isListening
              ? 'text-red-400 font-semibold animate-pulse'
              : isThinking
              ? 'text-cyan-400 font-semibold'
              : isSpeaking
              ? 'text-emerald-400 font-semibold'
              : !isSupported || permissionDenied
              ? 'text-slate-400'
              : 'text-slate-200'
          }`}
        >
          {!isSupported
            ? 'Speech recognition not available'
            : permissionDenied
            ? 'Microphone access is blocked'
            : isListening
            ? 'Listening...'
            : isThinking
            ? 'Thinking...'
            : isSpeaking
            ? 'Speaking...'
            : 'Tap the microphone to speak'}
        </p>
        <p className="text-xs text-slate-400 mt-1">
          {isListening
            ? 'Speak clearly into your microphone'
            : isThinking
            ? 'Processing with AI model...'
            : isSpeaking
            ? 'Reading response aloud'
            : 'Or type your message in the chat input below'}
        </p>
      </div>

      {/* Browser Support / Permission Warning Banner */}
      {!isSupported && (
        <div className="mt-3 flex items-center gap-2 text-xs text-amber-300/90 bg-amber-950/40 border border-amber-800/50 px-3 py-1.5 rounded-lg max-w-sm text-center">
          <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
          <span>For best voice recognition, use Google Chrome, Microsoft Edge, or Safari. You can still use the text chat below!</span>
        </div>
      )}

      {permissionDenied && (
        <div className="mt-3 flex items-center gap-2 text-xs text-rose-300/90 bg-rose-950/40 border border-rose-800/50 px-3 py-1.5 rounded-lg max-w-sm text-center">
          <MicOff className="w-4 h-4 shrink-0 text-rose-400" />
          <span>Microphone access was denied. Please allow microphone permissions in your browser address bar.</span>
        </div>
      )}
    </div>
  );
};
