import { VoiceAssistant } from '@/components/VoiceAssistant';

export const metadata = {
  title: 'VoxAI - Your Voice-Based Virtual Assistant',
  description:
    'Experience real-time voice interactions with VoxAI. Speak naturally via your microphone and receive intelligent spoken audio and text responses.',
};

export default function Home() {
  return <VoiceAssistant />;
}
