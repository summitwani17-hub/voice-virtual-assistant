/**
 * AI Core Service - VoxAI Virtual Assistant
 * Secure server-side processing for virtual assistant queries.
 * Supports Groq, OpenAI, Google Gemini, and a smart built-in fallback engine.
 */

export interface ChatMessageItem {
  role: 'user' | 'assistant' | 'system';
  content: string;
}

export interface AIProcessOptions {
  provider?: string;
  model?: string;
  systemPrompt?: string;
}

// Built-in intelligent fallback engine for zero-config demonstration and offline evaluation
function runLocalAssistantEngine(query: string): string {
  const q = query.trim().toLowerCase();

  // Dynamic Tip / Percentage Calculation
  const tipMatch = query.match(/(\d+(?:\.\d+)?)\s*%\s*(?:tip\s*(?:on|of)?|of)\s*\$?(\d+(?:\.\d+)?)/i);
  if (tipMatch) {
    const pct = parseFloat(tipMatch[1]);
    const amount = parseFloat(tipMatch[2]);
    const tip = (pct / 100) * amount;
    const total = amount + tip;
    return `A ${pct}% tip on $${amount.toFixed(2)} is $${tip.toFixed(2)}, making the total $${total.toFixed(2)}.`;
  }

  // Basic Arithmetic Calculations (requires at least one operator)
  const calcMatch = query.match(/(?:what is|calculate|solve|how much is)\s+([\d\s+\-*/x.()]+)/i);
  if (calcMatch && calcMatch[1] && /[+\-*/x]/.test(calcMatch[1])) {
    try {
      const sanitized = calcMatch[1].replace(/x/gi, '*').replace(/[^0-9+\-*/().]/g, '');
      if (sanitized.length > 0 && /^[\d\s+\-*/().]+$/.test(sanitized)) {
        // Safe evaluation of basic arithmetic
        const result = Function(`'use strict'; return (${sanitized})`)();
        if (typeof result === 'number' && !isNaN(result) && isFinite(result)) {
          return `The result of ${calcMatch[1].trim()} is ${Number(result.toFixed(4)).toString()}.`;
        }
      }
    } catch {
      // Fall through if parsing fails
    }
  }

  // Common concepts & study questions
  if (q.includes('quantum computing')) {
    return 'Quantum computing harnesses the quirks of quantum mechanics, like superposition and entanglement, to compute complex calculations exponentially faster than classical computers for specific problems.';
  }

  if (q.includes('photosynthesis')) {
    return 'Photosynthesis is the process by which green plants and some organisms turn sunlight, water, and carbon dioxide into oxygen and glucose for energy.';
  }

  if (q.includes('tip') && (q.includes('15%') || q.includes('84'))) {
    return 'A 15% tip on $84 is $12.60, making the total bill $96.60.';
  }

  if (q.includes('brainstorm') || q.includes('idea') || q.includes('habit tracker')) {
    return 'Here are three habit tracker ideas: First, a micro-journal that links habits to moods. Second, a streak buddy system with gentle audio nudges. Third, a gamified garden where each completed habit grows virtual plants.';
  }

  if (q.includes('summarize') || q.includes('summary')) {
    return 'To summarize effectively: identify the core thesis, extract 2 to 3 main supporting arguments, omit filler details, and restate the key takeaway in plain language.';
  }

  if (q.includes('solar energy') || q.includes('renewable')) {
    return 'Key benefits of solar energy include: it is an abundant and renewable power source, reduces electricity bills, produces zero greenhouse gas emissions during operation, and has low long-term maintenance costs.';
  }

  if (q.includes('who are you') || q.includes('what are you') || q.includes('your name')) {
    return 'I am VoxAI, your voice-based virtual assistant. You can speak to me or type questions, and I will help you with explanations, calculations, summaries, and everyday productivity tasks.';
  }

  if (q.includes('hello') || q.includes('hi ') || q === 'hi' || q.includes('hey')) {
    return 'Hello! I am ready to assist you. Tap the microphone and ask me anything, or type your request below.';
  }

  if (q.includes('how are you')) {
    return 'I am running smoothly and ready to help you with research, study questions, or ideas. What would you like to explore today?';
  }

  if (q.includes('send an email') || q.includes('call') || q.includes('book a flight') || q.includes('turn on lights')) {
    return 'I cannot interact directly with your external devices, email accounts, or booking services. However, I can help you draft the email or plan your itinerary!';
  }

  // General helpful conversational response
  return `I understand you are asking about "${query.slice(0, 80)}". While running in demo mode without an active API key, I can explain concepts, solve calculations, generate ideas, and assist with study questions. To enable full web-scale reasoning, configure GROQ_API_KEY, OPENAI_API_KEY, or GEMINI_API_KEY in your environment!`;
}

/**
 * Process a conversation with the chosen AI provider
 */
export async function processUserMessage(
  messages: ChatMessageItem[],
  options: AIProcessOptions = {}
): Promise<string> {
  if (!messages || messages.length === 0) {
    throw new Error('Message history cannot be empty.');
  }

  const lastUserMessage = [...messages].reverse().find((m) => m.role === 'user')?.content?.trim();
  if (!lastUserMessage) {
    throw new Error('No user message provided.');
  }

  const groqKey = process.env.GROQ_API_KEY;
  const openaiKey = process.env.OPENAI_API_KEY;
  const geminiKey = process.env.GEMINI_API_KEY;

  // Determine provider: priority order is explicit option -> GROQ -> OpenAI -> Gemini -> Demo
  let activeProvider = options.provider || process.env.AI_PROVIDER?.toLowerCase();
  if (!activeProvider) {
    if (groqKey) activeProvider = 'groq';
    else if (openaiKey) activeProvider = 'openai';
    else if (geminiKey) activeProvider = 'gemini';
    else activeProvider = 'demo';
  }

  const defaultVoiceSystemPrompt = `You are VoxAI, a knowledgeable, concise, and helpful voice assistant.
Guidelines:
1. Speak naturally and clearly in short, conversational paragraphs.
2. Avoid markdown syntax like asterisks, heavy bullet lists, or backticks that sound awkward when read aloud by Text-to-Speech engines.
3. Be accurate with facts and calculations.
4. When asked to perform actions you cannot do (like controlling hardware or accessing private external accounts), clearly state your limitation without pretending.
5. Keep responses concise (under 3-4 sentences when possible) for natural spoken dialog.`;

  const systemPrompt = options.systemPrompt || defaultVoiceSystemPrompt;

  // 1. GROQ PROVIDER (Fastest for real-time speech responses)
  if (activeProvider === 'groq' && groqKey) {
    const model = options.model || 'llama-3.3-70b-versatile';
    const formattedMessages = [
      { role: 'system', content: systemPrompt },
      ...messages.map((m) => ({ role: m.role, content: m.content })),
    ];

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);

    try {
      const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${groqKey}`,
        },
        body: JSON.stringify({
          model,
          messages: formattedMessages,
          temperature: 0.6,
          max_tokens: 450,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Groq API responded with status ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      return data.choices?.[0]?.message?.content?.trim() || 'I could not generate a response.';
    } catch (err: unknown) {
      if (err instanceof Error && err.name === 'AbortError') {
        throw new Error('Groq request timed out. Please try again.');
      }
      throw err;
    } finally {
      clearTimeout(timeout);
    }
  }

  // 2. OPENAI PROVIDER
  if (activeProvider === 'openai' && openaiKey) {
    const model = options.model || 'gpt-4o-mini';
    const formattedMessages = [
      { role: 'system', content: systemPrompt },
      ...messages.map((m) => ({ role: m.role, content: m.content })),
    ];

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);

    try {
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${openaiKey}`,
        },
        body: JSON.stringify({
          model,
          messages: formattedMessages,
          temperature: 0.6,
          max_tokens: 450,
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`OpenAI API responded with status ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      return data.choices?.[0]?.message?.content?.trim() || 'I could not generate a response.';
    } catch (err: unknown) {
      if (err instanceof Error && err.name === 'AbortError') {
        throw new Error('OpenAI request timed out. Please try again.');
      }
      throw err;
    } finally {
      clearTimeout(timeout);
    }
  }

  // 3. GOOGLE GEMINI PROVIDER
  if (activeProvider === 'gemini' && geminiKey) {
    const model = options.model || 'gemini-1.5-flash';
    const contents = messages
      .filter((m) => m.role !== 'system')
      .map((m) => ({
        role: m.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: m.content }],
      }));

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);

    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${geminiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents,
            systemInstruction: { parts: [{ text: systemPrompt }] },
            generationConfig: { temperature: 0.6, maxOutputTokens: 450 },
          }),
          signal: controller.signal,
        }
      );

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Gemini API responded with status ${response.status}: ${errorText}`);
      }

      const data = await response.json();
      return data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || 'I could not generate a response.';
    } catch (err: unknown) {
      if (err instanceof Error && err.name === 'AbortError') {
        throw new Error('Gemini request timed out. Please try again.');
      }
      throw err;
    } finally {
      clearTimeout(timeout);
    }
  }

  // 4. SMART FALLBACK ENGINE (When no API key is provided)
  return runLocalAssistantEngine(lastUserMessage);
}
