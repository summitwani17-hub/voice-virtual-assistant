import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
};

export const metadata: Metadata = {
  title: "VoxAI - Your Voice-Based Virtual Assistant",
  description:
    "AI-powered voice virtual assistant featuring speech-to-text, natural voice responses, and conversational intelligence. Built with Next.js 15+ App Router, TypeScript, and Tailwind CSS.",
  keywords: [
    "Voice Assistant",
    "LLM Activity",
    "Speech to Text",
    "Text to Speech",
    "Next.js",
    "React",
    "Groq",
    "OpenAI",
    "Gemini",
    "Virtual Assistant",
  ],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col bg-[#080b14] text-slate-100">{children}</body>
    </html>
  );
}
