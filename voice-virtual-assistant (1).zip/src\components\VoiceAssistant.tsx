'use strict';
'use client';

import React, { useState, useEffect, useRef } from 'react';
import {
  Send,
  Sparkles,
  Sun,
  Moon,
  ShieldCheck,
  AlertCircle,
  X,
  RotateCcw,
} from 'lucide-react';
import { MicrophoneButton, AssistantVoiceState } from '@/components/MicrophoneButton';
import { ChatMessage, Message } from '@/components/ChatMessage';
import { VoiceControls } from '@/components/VoiceControls';
import { useSpeechRecognition } from '@/hooks/useSpeechRecognition';
import { useSpeechSynthesis } from '@/hooks/useSpeechSynthesis';

const STARTER_PROMPTS = [
  'Explain quantum computing simply',
  'Brainstorm 3 habit tracker ideas',
  'What is 15% tip on $84?',
  'Summarize benefits of solar energy',
];

export const VoiceAssistant: React.FC = () => {
  // Theme state: dark / light
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  // Messages state
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome-1',
      role: 'assistant',
      content:
        'Hello! I am VoxAI, your voice-based virtual assistant. You can tap the microphone button to speak with me naturally, or type your question in the text box below.',
      timestamp: 'Just now',
    },
  ]);

  // Text input state
  const [inputText, setInputText] = useState('');
  const [isAiProcessing, setIsAiProcessing] = useState(false);
  const [currentlySpeakingId, setCurrentlySpeakingId] = useState<string | null>(null);
  const [voiceResponseEnabled, setVoiceResponseEnabled] = useState(true);
  const [generalError, setGeneralError] = useState<string | null>(null);

  // Chat scroll container ref
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Speech Recognition Hook
  const {
    isListening,
    transcript,
    interimTranscript,
    isSupported: isSttSupported,
    permissionDenied: micPermissionDenied,
    errorMessage: sttError,
    startListening,
    stopListening,
    cancelListening,
    resetTranscript,
  } = useSpeechRecognition({
    onTranscript: (text) => setInputText(text),
  });

  // Speech Synthesis Hook
  const {
    isSpeaking,
    isPaused,
    voices,
    selectedVoiceURI,
    setSelectedVoiceURI,
    rate: speechRate,
    setRate: setSpeechRate,
    speak,
    pause,
    resume,
    stop: stopSpeech,
  } = useSpeechSynthesis();

  // Sync dark class on body/html
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Determine current VoiceState
  let currentVoiceState: AssistantVoiceState = 'idle';
  if (isListening) {
    currentVoiceState = 'listening';
  } else if (isAiProcessing) {
    currentVoiceState = 'thinking';
  } else if (isSpeaking) {
    currentVoiceState = 'speaking';
  }

  // Scroll to bottom on new messages
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTo({
        top: chatScrollRef.current.scrollHeight,
        behavior: 'smooth',
      });
    }
  }, [messages, interimTranscript]);

  // Send message to AI endpoint
  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend !== undefined ? textToSend : inputText).trim();
    if (!query || isAiProcessing) return;

    // Stop listening if active
    if (isListening) {
      stopListening();
    }
    // Stop any existing speech playback
    stopSpeech();
    setCurrentlySpeakingId(null);
    setGeneralError(null);

    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      role: 'user',
      content: query,
      timestamp,
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    setInputText('');
    resetTranscript();
    setIsAiProcessing(true);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({
            role: m.role,
            content: m.content,
          })),
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server returned status ${response.status}`);
      }

      const data = await response.json();
      const replyText = data.message || data.content || 'I could not generate an answer at this time.';

      const assistantMessageId = `assistant-${Date.now()}`;
      const assistantMessage: Message = {
        id: assistantMessageId,
        role: 'assistant',
        content: replyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, assistantMessage]);

      // If voice responses are enabled, read aloud automatically
      if (voiceResponseEnabled) {
        setCurrentlySpeakingId(assistantMessageId);
        speak(replyText, () => {
          setCurrentlySpeakingId(null);
        });
      }
    } catch (err: unknown) {
      console.error('Failed to communicate with AI server:', err);
      const msg = err instanceof Error ? err.message : 'Network error. Please try again.';
      setGeneralError(msg);

      const errorMessage: Message = {
        id: `assistant-err-${Date.now()}`,
        role: 'assistant',
        content: `I'm sorry, but I encountered an error: ${msg}. Please verify your connection or try typing your question again.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsAiProcessing(false);
    }
  };

  // When speech recognition stops, auto-submit if text was captured
  const handleMicrophoneStop = () => {
    stopListening();
    const finalQuery = transcript.trim();
    if (finalQuery) {
      handleSendMessage(finalQuery);
    }
  };

  // Cancel microphone
  const handleMicrophoneCancel = () => {
    cancelListening();
    setInputText('');
  };

  // Manual speech playback for specific message
  const handleSpeakMessage = (text: string, messageId: string) => {
    stopSpeech();
    setCurrentlySpeakingId(messageId);
    speak(text, () => {
      setCurrentlySpeakingId(null);
    });
  };

  const handleStopSpeech = () => {
    stopSpeech();
    setCurrentlySpeakingId(null);
  };

  // Clear conversation
  const handleClearConversation = () => {
    stopSpeech();
    setCurrentlySpeakingId(null);
    setMessages([
      {
        id: 'welcome-reset',
        role: 'assistant',
        content: 'Conversation cleared. How can I help you next?',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
    setInputText('');
    resetTranscript();
    setGeneralError(null);
  };

  return (
    <div
      className={`min-h-screen flex flex-col items-center justify-between p-3 sm:p-6 transition-colors duration-300 ${
        theme === 'dark'
          ? 'bg-slate-950 text-slate-100'
          : 'bg-slate-50 text-slate-900'
      }`}
    >
      {/* Decorative ambient background glows */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl" />
        <div className="absolute top-1/3 -right-40 w-96 h-96 bg-violet-600/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 left-1/3 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl" />
      </div>

      {/* Top Header Bar */}
      <header className="w-full max-w-4xl flex items-center justify-between py-3 px-4 rounded-2xl glass-panel relative z-10 mb-4 shadow-xl">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-violet-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/20">
            <Sparkles className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-bold tracking-tight bg-gradient-to-r from-cyan-400 via-indigo-300 to-violet-400 bg-clip-text text-transparent">
              VoxAI
            </h1>
            <p className="text-xs text-slate-400">Your Voice-Based Virtual Assistant</p>
          </div>
        </div>

        {/* Right Header Actions: Theme Toggle & Reset */}
        <div className="flex items-center gap-2">
          {/* Theme Toggle Button */}
          <button
            type="button"
            onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
            className={`p-2 rounded-xl border transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-400 ${
              theme === 'dark'
                ? 'bg-slate-900/80 border-slate-700 text-amber-300 hover:bg-slate-800'
                : 'bg-white border-slate-300 text-slate-700 hover:bg-slate-100 shadow-sm'
            }`}
            title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
            aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Reset Chat Button */}
          <button
            type="button"
            onClick={handleClearConversation}
            className={`p-2 rounded-xl border transition-colors focus:outline-none focus:ring-2 focus:ring-cyan-400 ${
              theme === 'dark'
                ? 'bg-slate-900/80 border-slate-700 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                : 'bg-white border-slate-300 text-slate-600 hover:text-slate-900 hover:bg-slate-100 shadow-sm'
            }`}
            title="Reset conversation"
            aria-label="Reset conversation"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </header>

      {/* Main Assistant Stage: Microphone & Status */}
      <main className="w-full max-w-4xl flex-1 flex flex-col items-center justify-between relative z-10 gap-4">
        {/* Error Notification Banner */}
        {(generalError || sttError) && (
          <div
            role="alert"
            className="w-full flex items-center justify-between gap-3 px-4 py-2.5 rounded-xl bg-rose-950/70 border border-rose-800/80 text-rose-200 text-xs shadow-lg animate-fade-in"
          >
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400" />
              <span>{generalError || sttError}</span>
            </div>
            <button
              type="button"
              onClick={() => setGeneralError(null)}
              className="text-rose-400 hover:text-rose-200"
              aria-label="Dismiss error notice"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}

        {/* Center Microphone Button with Animated States */}
        <section
          aria-label="Voice input control"
          className="w-full flex flex-col items-center justify-center pt-2 sm:pt-4"
        >
          <MicrophoneButton
            voiceState={currentVoiceState}
            isSupported={isSttSupported}
            permissionDenied={micPermissionDenied}
            onStart={startListening}
            onStop={handleMicrophoneStop}
            onCancel={handleMicrophoneCancel}
            disabled={isAiProcessing}
          />

          {/* Real-time interim voice transcription preview */}
          {isListening && (
            <div className="w-full max-w-md mt-2 px-4 py-2 rounded-xl bg-slate-900/80 border border-cyan-500/40 text-center animate-pulse">
              <p className="text-xs text-cyan-300 font-mono italic">
                {interimTranscript || transcript || 'Listening to your voice...'}
              </p>
            </div>
          )}

          {/* Quick Prompt Chips */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-4 max-w-2xl px-2">
            {STARTER_PROMPTS.map((prompt, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleSendMessage(prompt)}
                disabled={isAiProcessing || isListening}
                className="text-xs px-3 py-1.5 rounded-full border border-slate-700/60 bg-slate-900/50 hover:bg-slate-800 hover:border-cyan-500/40 text-slate-300 hover:text-cyan-300 transition-all focus:outline-none focus:ring-2 focus:ring-cyan-400 disabled:opacity-50"
              >
                {prompt}
              </button>
            ))}
          </div>
        </section>

        {/* Conversation Panel */}
        <section
          aria-label="Conversation history"
          className={`w-full flex-1 flex flex-col rounded-2xl border shadow-xl backdrop-blur-xl overflow-hidden transition-colors ${
            theme === 'dark'
              ? 'bg-slate-900/60 border-slate-800'
              : 'bg-white/80 border-slate-200'
          }`}
          style={{ minHeight: '280px', maxHeight: '420px' }}
        >
          {/* Conversation Panel Scroll Area */}
          <div
            ref={chatScrollRef}
            className="flex-1 overflow-y-auto p-4 space-y-2 focus:outline-none"
            tabIndex={0}
            role="log"
            aria-live="polite"
            aria-label="Chat messages"
          >
            {messages.map((msg) => (
              <ChatMessage
                key={msg.id}
                message={msg}
                isCurrentlySpeaking={currentlySpeakingId === msg.id}
                onSpeak={handleSpeakMessage}
                onStopSpeech={handleStopSpeech}
              />
            ))}

            {/* AI Thinking Indicator in conversation */}
            {isAiProcessing && (
              <div className="flex items-center gap-3 w-full my-2 animate-pulse">
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-purple-600 to-indigo-700 text-white flex items-center justify-center text-xs shadow-md">
                  AI
                </div>
                <div className="px-4 py-3 rounded-2xl rounded-tl-none bg-slate-900/70 border border-slate-800 text-slate-400 text-xs flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                  <span>Thinking and generating voice answer...</span>
                </div>
              </div>
            )}
          </div>

          {/* Voice Controls: Toggle Voice, Pause/Resume/Stop, Voice Picker, Clear */}
          <div className="px-4 bg-slate-950/40">
            <VoiceControls
              voiceEnabled={voiceResponseEnabled}
              onToggleVoice={() => setVoiceResponseEnabled(!voiceResponseEnabled)}
              isSpeaking={isSpeaking}
              isPaused={isPaused}
              onPauseSpeech={pause}
              onResumeSpeech={resume}
              onStopSpeech={handleStopSpeech}
              voices={voices}
              selectedVoiceURI={selectedVoiceURI}
              onSelectVoice={setSelectedVoiceURI}
              speechRate={speechRate}
              onChangeRate={setSpeechRate}
              onClearConversation={handleClearConversation}
              messageCount={messages.length}
            />
          </div>

          {/* Text Input Fallback & Send Button */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-3 bg-slate-950/60 border-t border-slate-800/80 flex items-center gap-2"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Type your message or tap the microphone above..."
              disabled={isAiProcessing}
              className={`flex-1 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-cyan-400 border transition-colors ${
                theme === 'dark'
                  ? 'bg-slate-900 border-slate-700 text-slate-100 placeholder-slate-500'
                  : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400'
              }`}
              aria-label="Text message input"
            />
            <button
              type="submit"
              disabled={!inputText.trim() || isAiProcessing}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-medium text-sm flex items-center gap-1.5 transition-all shadow-md shadow-cyan-600/30 disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-cyan-400"
              aria-label="Send message"
            >
              <span>Send</span>
              <Send className="w-4 h-4" />
            </button>
          </form>
        </section>
      </main>

      {/* Footer & Privacy Badge */}
      <footer className="w-full max-w-4xl flex flex-wrap items-center justify-between gap-3 text-[11px] text-slate-400 py-3 px-4 mt-2">
        <div className="flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>Privacy Protected: Audio is never stored permanently. Processed only during active microphone use.</span>
        </div>
        <div className="flex items-center gap-3">
          <span>Vercel Ready</span>
          <span>•</span>
          <span>Web Speech API</span>
        </div>
      </footer>
    </div>
  );
};
